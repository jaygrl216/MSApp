package com.example.jada.lab10;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Bundle;
import android.util.AttributeSet;
import android.support.v7.widget.AppCompatEditText;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;

public class MainActivity extends Activity {
    LinedEditText editText;
    Button left;
    Button right;

    public static class LinedEditText extends AppCompatEditText {
        private Rect mRect;
        private Paint mPaint;

        // This constructor is used by LayoutInflater
        public LinedEditText(Context context, AttributeSet attrs) {
            super(context, attrs);

            // Creates a Rect and a Paint object, and sets the style and color of the Paint object.
            mRect = new Rect();
            mPaint = new Paint();
            mPaint.setStyle(Paint.Style.STROKE);
            mPaint.setColor(0x800000FF);
        }

        /**
         * This is called to draw the LinedEditText object
         * @param canvas The canvas on which the background is drawn.
         */
        @Override
        protected void onDraw(Canvas canvas) {

            // Gets the number of lines of text in the View.
            int count = getLineCount();

            // Gets the global Rect and Paint objects
            Rect r = mRect;
            Paint paint = mPaint;
            paint.setStrokeWidth(4);

            /*
             * Draws one line in the rectangle for every line of text in the EditText
             */
            for (int i = 0; i < count; i++) {

                // Gets the baseline coordinates for the current line of text
                int baseline = getLineBounds(i, r);

                /*
                 * Draws a line in the background from the left of the rectangle to the right,
                 * at a vertical position one dip below the baseline, using the "paint" object
                 * for details.
                 */
                canvas.drawRect(r,paint);
//                canvas.drawLine(r.left, baseline + 1, r.right, baseline + 1, paint);
//                canvas.drawLine(r.left, baseline - 1, r.right, baseline - 1, paint);
            }

            // Finishes up by calling the parent method
            super.onDraw(canvas);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText = (LinedEditText) findViewById(R.id.note);
        left = (Button) findViewById(R.id.button);
        right = (Button) findViewById(R.id.button2);
        registerForContextMenu(editText);
    }

    public void toggleRight(View v) {
        if(right.getVisibility() == View.VISIBLE) {
            right.setVisibility(View.INVISIBLE);
            System.out.print(right.getVisibility());
        } else {
            right.setVisibility(View.VISIBLE);
        }
    }

    public void toggleLeft(View v) {
       if(left.getVisibility() == View.VISIBLE) {
           left.setVisibility(View.INVISIBLE);
           System.out.println(right.getVisibility() == View.VISIBLE);
       } else {
           left.setVisibility(View.VISIBLE);
       }

    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        switch (item.getItemId()) {
            case R.id.now:
                editText.append("Do Now: ");
                return true;
            case R.id.later:
                editText.append("Do Later: ");
                return true;
            case R.id.never:
                editText.append("Do Never: ");
                return true;
            default:
                return super.onContextItemSelected(item);
        }
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v,
                                    ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
    }
}
