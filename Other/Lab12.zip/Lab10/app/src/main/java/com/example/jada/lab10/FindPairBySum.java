package com.example.jada.lab10;

/**
 * Created by Jada on 5/8/2017.
 */

/**
 This class read an integer array from the ArrayInputStream. And find the two numbers
 in the array that sums to a given number, and return the index of the first number found.
 In you test, you need to use Mockito to mock ArrayInputStream.
 */
public class FindPairBySum {

    private ArrayInputStream in;

    public FindPairBySum(ArrayInputStream in) {
        this.in = in;
    }

    public int getFirstIdxBySum(int inputOffset, int sum) {
        int[] a = in.readArray(inputOffset);
        if(a == null || a.length < 2) {
            throw new RuntimeException("Array must contain at least 2 elements.");
        }
        return getFirstIdxBySum(a, sum, 0, a.length - 1);
    }

    private int getFirstIdxBySum(int[] a, int sum, int startIdx, int endIdx) {
        int result = -1;
        while(startIdx < endIdx && a[startIdx] + a[endIdx] != sum) {
            while(a[startIdx] + a[endIdx] > sum) {
                endIdx--;
            }
            if(a[startIdx] + a[endIdx] < sum) {
                startIdx++;
            }
        }
        if(startIdx < endIdx) {
            result = startIdx;
        }
        return result;
    }
}
