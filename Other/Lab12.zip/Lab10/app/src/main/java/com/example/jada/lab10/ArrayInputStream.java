package com.example.jada.lab10;

/**
 * Created by Jada on 5/8/2017.
 */

public interface ArrayInputStream {
    int[] readArray(int i);
}
