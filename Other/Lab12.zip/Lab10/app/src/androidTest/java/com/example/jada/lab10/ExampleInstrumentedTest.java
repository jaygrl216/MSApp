package com.example.jada.lab10;

import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;


import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.clearText;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.action.ViewActions.longClick;
import static android.support.test.espresso.action.ViewActions.typeText;
import static android.support.test.espresso.assertion.ViewAssertions.matches;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withText;

import static org.hamcrest.core.IsNot.not;


/**
 * Instrumentation test, which will execute on an Android device.
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
@RunWith(AndroidJUnit4.class)
public class ExampleInstrumentedTest {

    @Rule
    public ActivityTestRule<MainActivity> activityRule =
            new ActivityTestRule<>(MainActivity.class);

    /**
     *
     * checks to see if the left button is visible and when clicked that button button is not
     */
    @Test
    public void leftButtonTest() throws Exception {
        onView(withId(R.id.button)).check(matches(isDisplayed()));
        onView(withId(R.id.button)).perform(click());
        onView(withId(R.id.button2)).check(matches(not(isDisplayed())));
        onView(withId(R.id.button)).check(matches(isDisplayed()));

    }

    /**
     *
     * checks to see if the right button is visible and when clicked that left button is not
     */
    @Test
    public void rightButtonTest() throws Exception {
        onView(withId(R.id.button2)).check(matches(isDisplayed()));
        onView(withId(R.id.button2)).perform(click());
        onView(withId(R.id.button)).check(matches(not(isDisplayed())));
        onView(withId(R.id.button2)).check(matches(isDisplayed()));

    }

    /**
     * Test text is clear on clearText()
     */
    @Test
    public void clearEditText() throws Exception {
        onView(withId(R.id.note)).perform(typeText("testing 123"));
        onView(withId(R.id.note)).perform(clearText());
        onView(withId(R.id.note)).check(matches(withText("")));
    }

    /**
     * Basic test on edit text
     */
    @Test
    public void testEditText() throws Exception {
        onView(withId(R.id.note)).perform(typeText("testing 123"));
        onView(withId(R.id.note)).check(matches(withText("testing 123")));
    }

    /**
     * Test if popup menu gets clicked and appended to edit text
     */
    @Test
    public void testMenuItems() throws Exception {
        onView(withId(R.id.note)).perform(longClick());
        onView(withText("Do Now")).check(matches(isDisplayed())).perform(click());
        onView(withId(R.id.note)).perform(typeText("testing 123"));
        onView(withId(R.id.note)).check(matches(withText("Do Now: testing 123")));


    }
}
