package com.example.jada.lab10;

import org.junit.Test;
import org.mockito.Mock;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class MockitoTest {
    @Mock
    ArrayInputStream mockStream = mock(ArrayInputStream.class);

    /**
     * Boundary Test Case
     */
    @Test
    public void testBoundary() throws Exception {
        int[] values = {1,2,3,4,5,6,7};
        when(mockStream.readArray(7)).thenReturn(values);

        FindPairBySum mockedPair = new FindPairBySum(mockStream);
        assertEquals(mockedPair.getFirstIdxBySum(7,8), 0);
    }

    /**
     * RuntimeException Test Case
     */
    @Test
    public void testRuntimeException() throws Exception {
        int[] values = {1};
        boolean exception = false;

        when(mockStream.readArray(1)).thenReturn(values);

        FindPairBySum mockedPair = new FindPairBySum(mockStream);

        try {
            mockedPair.getFirstIdxBySum(1,2);
        } catch (RuntimeException e) {
            exception = true;
        }

        assertTrue(exception);
    }

    /**
     * Normal Test Case 1
     */
    @Test
    public void test1() throws Exception {
        int[] values = {3,4,5,7,20,100};

        when(mockStream.readArray(100)).thenReturn(values);

        FindPairBySum mockedPair = new FindPairBySum(mockStream);
        assertEquals(mockedPair.getFirstIdxBySum(100,27), 3);

    }

    /**
     * Normal Test Case 2
     */
    @Test
    public void test2() throws Exception {
        int[] values = {2,4,6,9};

        when(mockStream.readArray(4)).thenReturn(values);

        FindPairBySum mockedPair = new FindPairBySum(mockStream);
        assertEquals(mockedPair.getFirstIdxBySum(4,10), 1);


    }

    /**
     * No Pair Found Test Case
     */
    @Test
    public void noPairFound() throws Exception {
        int[] values = {1,2,3,4,5};

        when(mockStream.readArray(5)).thenReturn(values);

        FindPairBySum mockedPair = new FindPairBySum(mockStream);
        assertEquals(mockedPair.getFirstIdxBySum(5,10), -1);


    }



}