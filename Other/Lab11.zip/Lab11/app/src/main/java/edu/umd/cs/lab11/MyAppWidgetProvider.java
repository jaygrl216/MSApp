package edu.umd.cs.lab11;

import android.app.Activity;
import android.appwidget.AppWidgetProvider;
import android.os.Bundle;

public class MyAppWidgetProvider extends AppWidgetProvider {
}
